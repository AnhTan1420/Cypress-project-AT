(function (window, $) {
	$(document).ready(function () {
		$("body").on("click", "#pda_gold_signup_newsletter", function (evt) {
			evt.preventDefault();
			var email = $("#pda_gold_signup_newsletter_input").val().trim();
		  	var emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			$("#pda_gold_signup_newsletter").val("Saving...");
			if (email && emailPattern.test(email)) {
				$.ajax({
					url: newsletter_data.newsletter_url,
					type: 'POST',
					data: {
						action: 'pda_gold_subscribe',
						security_check: newsletter_data.newsletter_nonce,
						email: email
					},
					success: function (data) {
						$(".pda_sub_form").hide();
						$(".newsletter_inform").show("slow");
						console.log("Success", data);
						$("#pda_gold_signup_newsletter").val("Get Lucky");
					},
					error: function (error) {
						$(".pda_sub_form").hide();
						$(".newsletter_inform").show("slow");
						$("#pda_gold_signup_newsletter").val("Get Lucky");
					}
				});
			} else {
				$("#pda_signup_newsletter_error").show("slow");
				$("#pda_signup_newsletter").focus();
				$("#pda_gold_signup_newsletter").val("Get Lucky");
			}
		});
	});
})(window, jQuery);
