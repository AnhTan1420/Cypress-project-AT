<?php
/**
 * Created by PhpStorm.
 * User: gaupoit
 * Date: 4/2/18
 * Time: 10:25
 */

return (object) array(
	'debug_mode' => false,
	'app_id'     => "584087",
	'email_api'  => 'https://loks4vx5i7.execute-api.ap-southeast-1.amazonaws.com/prod/mail',
	'email_key'  => 'SUDi1LNlAv3T2nQ4QIX9Sadtr7Ghg9UD1PnHvyWe',
	'pda_lg_api' => 'https://lflr61ex79.execute-api.ap-southeast-1.amazonaws.com/staging/pets',
	'lc_key'     => 'VB4bUdzE566B1IyrK7uO03gSQtY2qLrs8RzCs8ry',
	'time_l_c'   => 60 * 60 * 24,
	'update_url' => 'https://j59dqwbnzk.execute-api.ap-southeast-1.amazonaws.com/prod/hello?action=get_metadata&slug=prevent-direct-access-gold-3.0',
);
