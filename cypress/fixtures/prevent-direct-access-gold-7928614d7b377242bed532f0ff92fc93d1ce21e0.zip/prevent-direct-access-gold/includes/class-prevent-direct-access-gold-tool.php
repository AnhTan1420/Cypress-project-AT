<?php

class PDA_Tool {
	public function render_ui() {
		wp_enqueue_script(
			'pda-tool-js',
			plugin_dir_url( PDA_V3_PLUGIN_BASE_FILE ) . 'js/submenu-tool/submenu-tool.js',
			array(),
			PDA_GOLD_V3_VERSION,
			false
		);

		wp_localize_script(
			'pda-tool-js',
			'pdaTool',
			array(
				'local_url' => PDA_BASE_URL,
				'rest_url' => get_rest_url( null, '/pda/v3' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'timeout'  => apply_filters( 'pda_request_timeout', 5000 ),
				'version'  => PDA_GOLD_V3_VERSION
			)
		);

		?>
		<div id="pda-tool"></div>
		<?php
	}
}
