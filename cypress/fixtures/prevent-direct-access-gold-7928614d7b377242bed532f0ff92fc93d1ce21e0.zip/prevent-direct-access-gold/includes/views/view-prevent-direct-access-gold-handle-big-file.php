<?php
$should_handle_big_file_checked = $setting->getSettings( PDA_v3_Constants::PDA_SHOULD_HANDLE_BIG_FILE ) ? 'checked' : '';

?>

<tr>
	<td>
		<label class="pda_switch" for="pda_should_handle_big_file">
			<input type="checkbox" id="pda_should_handle_big_file" name="pda_should_handle_big_file" <?php echo $should_handle_big_file_checked; ?>/>
			<span class="pda-slider round"></span>
		</label>
	</td>
    <td>
        <p>
            <label><?php echo esc_html__( 'Download Large-size Files', 'prevent-direct-access-gold' ); ?><span class="pda_beta">BETA</span></label>
	        <?php echo esc_html__( 'Enable this option when you allow ', 'prevent-direct-access-gold' ); ?>
			<a href="https://preventdirectaccess.com/docs/settings/?utm_source=user-website&utm_medium=setting-general&utm_campaign=pda-gold#large-files" target="_blank"><?php echo esc_html_e( 'downloading large-size files', 'prevent-direct-access-gold' ) ?></a><?php echo esc_html_e( '. The option will be turned on by default in the upcoming versions.', 'prevent-direct-access-gold' ) ?>
        </p>
    </td>
</tr>
