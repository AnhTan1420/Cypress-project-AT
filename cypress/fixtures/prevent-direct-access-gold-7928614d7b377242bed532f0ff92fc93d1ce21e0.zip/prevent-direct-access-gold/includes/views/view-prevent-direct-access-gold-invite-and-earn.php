<?php
    $url = PDA_BASE_URL . "public/assets/pda-gold-affiliate-settings-banner.png";
?>
<div>
    <a class="pda-affiliate-program-setting" target="_blank" href="http://bit.ly/joinpdaff">
        <img width="100%" src="<?php echo esc_attr($url) ?>">
    </a>
</div>