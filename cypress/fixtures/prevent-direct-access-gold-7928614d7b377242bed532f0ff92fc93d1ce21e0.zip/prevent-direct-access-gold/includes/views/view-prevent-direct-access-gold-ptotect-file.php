<tr>
    <td>
        <label class="pda_switch" for="hide_protected_files_in_media">
            <input type="checkbox" id="hide_protected_files_in_media"
                name="hide_protected_files_in_media" <?php echo $hide_protected_files_in_media ?>  />
            <span class="pda-slider round"></span>
        </label>
    </td>

    <td>
        <p>
            <label><?php echo esc_html__( 'Hide protected files in Media Library', 'prevent-direct-access' ) ?>
            </label>
            <?php echo esc_html__( 'Hide protected files in Media Library', 'prevent-direct-access' ) ?>
        </p>
    </td>
</tr>