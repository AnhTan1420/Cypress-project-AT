<?php
/**
 * Created by PhpStorm.
 * User: gaupoit
 * Date: 3/7/18
 * Time: 14:11
 */

return (object)array(
    'addon_endpoint' => ' https://22ueajq0ul.execute-api.ap-southeast-1.amazonaws.com/develop',
    'aok' => 'qT5x2UyCMAmAwdpeXCbM54IPxq7DtcQ8b18tJg6i',
    'lc_api' => 'https://ezkpu2vcbg.execute-api.ap-southeast-1.amazonaws.com/staging/pets',
    'elc_api' => 'https://rtidbnqwvk.execute-api.ap-southeast-1.amazonaws.com/staging/pets',
    'lc_key' => 'VB4bUdzE566B1IyrK7uO03gSQtY2qLrs8RzCs8ry',
    'lu_api' => 'https://a0fovp9vp3.execute-api.ap-southeast-1.amazonaws.com/dev/license/update-domain',
    'lu_key' => 'iqNuA6Kahv1Km1OlJMDqg59lwVbSLAoO7GYXPDBu',
    'ad_api' => 'https://a0fovp9vp3.execute-api.ap-southeast-1.amazonaws.com/dev/license/available-domain',
);